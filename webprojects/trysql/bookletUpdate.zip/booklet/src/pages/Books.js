import React from 'react'
import Hero from '../components/Hero'
import Card from '@material-ui/core/Card';
import Button from "@material-ui/core/Button";
import RecipeReviewCard from '../components/SingleBookCart'


const Books = () => {
    return (
        <div>
        <Hero hero="roomsHero"></Hero>
            Hello from book page
           <RecipeReviewCard/>
        </div>
    )
}

export default Books
