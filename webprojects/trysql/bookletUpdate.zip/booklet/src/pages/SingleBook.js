import React, { Component } from 'react'

export default class SingleBook extends Component {
    render() {
        return (
            <div>
                hello from single book
            </div>
        )
    }
}
