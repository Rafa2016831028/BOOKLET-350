import styled from 'styled-components';

const MainDiv = styled.div`
    display: flex;
    flex-flow: column wrap;
    margin-top: 50px;
	margin-bottom: 50px;
	background : #F5F5F5;
`;
export default MainDiv;
